# Smart Contact Manager using Spring-Boot-API :smiling_face_with_three_hearts:

### Home Page
![](https://github.com/sndp231998/smartcontactmanagerr
boot/blob/master/src/main/resources/static/img/gitimg2.PNG)


### User Dashboard
![](https://github.com/sndp231998/smartcontactmanagerr
boot/blob/master/src/main/resources/static/img/gitimg1.PNG)


### Contact Profile
![](https://github.com/sndp231998/smartcontactmanagerr
![]https://github.com/sndp231998/smartcontactmanagerr
/blob/master/src/main/resources/static/img/gitimg3.PNG)


## developed by -  sandip chapagain
  ### 
  
Download this project using Github CLI -
 > `gh repo clone https://github.com/sndp231998/smartcontactmanagerr`
